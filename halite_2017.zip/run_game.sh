#!/bin/sh

./halite "python3 MyBot.py" "python3 MyBot_v2.py"
